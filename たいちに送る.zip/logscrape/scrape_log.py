import os
import pprint
import time
import urllib.error
import urllib.request
import gzip
import shutil
import datetime
from datetime import date,timedelta
import download4



def download_file(url, dst_path):
    try:
        with urllib.request.urlopen(url) as web_file:
            data = web_file.read()
            with open(dst_path, mode='wb') as local_file:
                local_file.write(data)
    except urllib.error.URLError as e:
        print(e)


if __name__ == "__main__":
    dt_now = datetime.datetime.now()
    yyyymmdd = dt_now.strftime('%Y%m%d')
    # dt_1day_past = dt_now - timedelta(days=1) # 1時間前のログを探す
    # yyyymmdd = dt_1day_past.strftime('%Y%m%d')
    print(yyyymmdd)

    fname = 'sca{}.log.gz'.format(yyyymmdd)
    URL = "https://tenhou.net/sc/raw/dat/"+fname
    
    dst_path = 'scrape.gz'
    download_file(URL, dst_path)

    with gzip.open('scrape.gz', mode='r') as f_in:
        with open('scrape.txt', 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    with open('scrape.txt') as f:
        lines = f.readlines()


    download4.download("/logvol4.txt","temp.txt")
    with open("temp.txt",'a') as f:
        f.write("{}\n".format(yyyymmdd))
        for line in lines:
            roomid = line.split()[0]
            if roomid == "C8823":
                f.write("{}".format(line)) 
                

    download4.upload("temp.txt","/logvol4.txt")   
     
    
    ###