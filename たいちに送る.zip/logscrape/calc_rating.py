import os
import pprint
import time
import urllib.error
import urllib.request
import gzip
import shutil
import datetime
from datetime import date,timedelta
import download4





if __name__ == "__main__":
    download4.download("/logvol3.txt","log.txt")